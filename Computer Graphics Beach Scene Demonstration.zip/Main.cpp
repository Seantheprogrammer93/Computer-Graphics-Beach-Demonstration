#include "LineHeader.H"

int main()
{
	LineProperties myLine;
	myLine.generateBeach();
}